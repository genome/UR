{% include install/download.html %}

It is also availabe from [CPAN](http://search.cpan.org/search?mode=all&query=UR).

{% include install/github.html %}
{% include install/help.html %}
{% include install/manuals.html %}
