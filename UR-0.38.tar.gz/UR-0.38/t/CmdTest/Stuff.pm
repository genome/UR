package CmdTest::Stuff;

class CmdTest::Stuff {
    has => [
        foo => { is => "Text" },
    ]
};

1;

