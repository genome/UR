package CdExample;
use UR;

class CdExample {
    is => 'UR::Namespace'
};

1;

