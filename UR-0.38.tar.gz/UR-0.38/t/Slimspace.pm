package Vending;

use warnings;
use strict;

use UR;

class Vending {
    is => [ 'UR::Namespace' ],
    doc => 'Used by the namespace_loaded_from_symlink test',
};

1;
