use strict;
use warnings;

package URTAlternate;

use UR;

class URTAlternate {
    is => ['UR::Namespace'],
    doc => 'A dummy namespace used by the UR test suite.',
};

1;
#$Header
