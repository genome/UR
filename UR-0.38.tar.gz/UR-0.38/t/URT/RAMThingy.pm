package URT::RAMThingy;

use warnings;
use strict;

use UR::Object::Type;

use URT;
class URT::RAMThingy {
};

1;

