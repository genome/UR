package Vending::Vocabulary;

use warnings;
use strict;

use UR;

class Vending::Vocabulary {
    is => [ 'UR::Vocabulary' ],
};


1;
