package Vending::Command::Service;

use strict;
use warnings;
use Vending;

class Vending::Command::Service {
    is => 'Vending::Command',
    doc => 'Service-mode commands',
};

    
1;

