package Vending::Command::Service::Show;
use strict;
use warnings;

use Vending;
class Vending::Command::Service::Show {
    is => 'Vending::Command::Service',
    doc => 'Various sub-commands to query the machine state',
};

1;

