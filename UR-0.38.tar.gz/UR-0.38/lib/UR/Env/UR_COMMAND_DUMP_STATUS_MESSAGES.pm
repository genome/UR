package UR::Env::UR_COMMAND_DUMP_STATUS_MESSAGES;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
