package UR::Env::UR_CONTEXT_CACHE_SIZE_HIGHWATER;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
