package UR::Env::UR_NR_CPU;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
