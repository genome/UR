package UR::Env::UR_USE_ANY;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
