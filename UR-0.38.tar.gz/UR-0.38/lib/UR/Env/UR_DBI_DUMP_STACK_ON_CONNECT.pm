package UR::Env::UR_DBI_DUMP_STACK_ON_CONNECT;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
