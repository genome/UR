package UR::Env::UR_DBI_MONITOR_SQL;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
