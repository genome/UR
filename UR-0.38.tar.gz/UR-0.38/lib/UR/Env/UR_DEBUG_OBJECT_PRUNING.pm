package UR::Env::UR_DEBUG_OBJECT_PRUNING;
use strict;
use warnings;
require UR;
our $VERSION = "0.38"; # UR $VERSION;
1;
