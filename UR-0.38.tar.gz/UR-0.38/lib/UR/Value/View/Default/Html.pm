package UR::Value::View::Default::Html;
use strict;
use warnings;
use UR;

class UR::Value::View::Default::Html {
    is => 'UR::Value::View::Default::Text',
};

1;
