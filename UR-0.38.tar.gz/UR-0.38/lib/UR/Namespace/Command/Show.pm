package UR::Namespace::Command::Show;
use strict;
use warnings;

class UR::Namespace::Command::Show {
    is => 'Command::Tree',
    doc => 'show data about classes, data storage',
};

1;

