use strict;
use warnings;

package URTAlternate;

use UR;

class URTAlternate {
    is => ['UR::Namespace'],
    type_name => 'urtalternate',
    doc => 'A dummy namespace used by the UR test suite.',
};

1;
#$Header
